from django.db import models

# Create your models here.

class CSV_data(models.Model):
    id=models.AutoField(primary_key=True)
    nz_port=models.CharField(max_length=250)
    citizenship=models.CharField(max_length=255)
    count=models.CharField(max_length=255)
    year=models.CharField(max_length=255)



    def __str__(self):
        return self.nz_port