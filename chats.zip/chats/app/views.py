from django.shortcuts import render,redirect
from .models import CSV_data
from django.http import HttpResponse,request
# Create your views here.

       
def index(request):
    
    if request.method == "POST":
        file_data = request.FILES.get('csv_data')
        if file_data:
            with file_data.open('rb') as file:
                file_content = file.read().decode('utf-8').splitlines()
                for line in file_content:
                    values = line.split(',')  
                    if len(values) >= 5:  
                         csv_data = CSV_data(
                                nz_port=values[0],
                                citizenship=values[1],
                                count=values[2],
                                year=values[3],
                                
                            )
                         csv_data.save()
                        
                    
            return redirect('index')
        
    return render(request,'index.html')
        
   
from django.http import JsonResponse
import json

def fetch(request):
    data = list(CSV_data.objects.values('citizenship', 'year'))
    return JsonResponse(data, safe=False)


def delete(request):
    CSV_data.objects.all().delete()
    return redirect('index')
