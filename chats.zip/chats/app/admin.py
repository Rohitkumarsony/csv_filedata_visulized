from django.contrib import admin
from .import views
from .models import CSV_data

# Register your models here.

admin.site.register(CSV_data)
